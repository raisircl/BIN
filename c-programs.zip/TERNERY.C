/*
Ternery Operator - Operates on 3 Operand
? then
: otherwise

syntax
condition ? expr1-work : expr2-work;

condition ? (condition?expr1:expr2) : (condition?expr1:expr2);

*/
#include<stdio.h>
#include<conio.h>
void main()
{
  int a,b,c;
  clrscr();
  printf("\nenter 2 nos");
  scanf("%d%d",&a,&b);

  a>b ? printf("\nA is Biggest") : printf("\nB is biggest");

  c = a>b ? a : b;

  printf("\nBiggest Number is %d",c);

  getch();
}
//biggest between 3 nos using ternery operator

/*

enter working hour of an employee and calculate daily wage

wh	wage
8	350
over time
wh		wage per hour
>8 upto 10      50
>10 upto 12	75
>12 upto 14	100

other wise ivalid input

11

8   350
9    50
10   50
11   75
----------
    525

*/
