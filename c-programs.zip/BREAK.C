/*
Break Statement
syntax:
  for(  ;    ;   )
  {
     ...
     break; ------
     .....       -
  }              -    Break transfer the control outside the loop
  ....           -    cause of break become un natural death of loop
  ....    <-------    emergency exit from loop

1. enter a number check it it prime or not
*/
#include<stdio.h>
#include<conio.h>
void main()
{
  int num,i;
  clrscr();
  printf("\nenter a number");
  scanf("%d",&num);  // 5, 9
  for(i=2;i<num;i++) // 2, 3, 4, 5 ,2,3
  {
      if(num%i==0)  //5%2==0=>F, 5%3==0=>F, 5%4==0>F, 9%2==0>F, 9%3==0=>T
      {
	break;
      }
   }
   if(i==num) //5==5, 3==9
   {
      printf("\n%d is prime number",num);
   }
   else
   {
     printf("\n%d is not prime number",num);
   }
  getch();
}
/*

*/

