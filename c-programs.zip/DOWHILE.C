/*
do-while
 1. Unkown Loop
 2. Condition Control
 3. Exit Control
 4. Also known as Odd Loop
Syntax:
 do
 {
   ....
   .....
 }while(condition);

During entry inside loop there is no condition
It always execute once so it is called odd loop
Application -

It is used for menu driven programming.

*/
#include<stdio.h>
#include<conio.h>
void main()
{
    int n1,n2,r,choice;
    clrscr();
    do
    {
      printf("\nenter 2 nos");
      scanf("%d%d",&n1,&n2);
      r=n1+n2;
      printf("\nSum=%d",r);

      printf("\nEnter 1 for Sum and Other key to exit");
      scanf("%d",&choice);
    }while(choice==1);
}
/*
Increase Choices
1. Sum
2. Subtract
3. Product
4. Division
5. Exit


*/


