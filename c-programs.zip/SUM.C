#include<stdio.h>
#include<conio.h>
void main()
{
   int n1,n2,t; // variable - used to store data
   clrscr();// clrscr is a function used to clear the screen
   n1=100; // assignment - put value into variable
   n2=200;
   t=n1+n2;
   printf("\nThe sum is %d",t);
   getch();
}