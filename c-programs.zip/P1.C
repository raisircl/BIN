/*
Aim - First program of C
Author - Rai
Date - 29 Aug 2023
*/
#include<stdio.h>
#include<conio.h>
void main()
{
  clrscr();
  printf("\nHello User");
  printf("\nWelcome in C");
  getch();
}// end of program

/*
Symbols -
/ forward slash
- hyphen
* aterisk
# hash
<> angular bracket
. dot
() parenthesis
; semicolon
"" double quotes
\ backward slash
{} braces
program explaination -
1. comment - it is used to give short description about your code
it helps to make your program easy to understand
2 types of comment -
	1. line comment - syntax is //.............................
	2. paragraph comment -
		/*
			--------
		*/
/*
#include -  it is known as pre processor directive it directs to pre processor
to insert inbuilt functions of header file into your program

Header File - it is collection of inbuilt functions
There are 2 standard header file used in each program of c
1. stdio.h => standard input output
2. conio.h =>console input output

void -> it is a keyword. it is reserve word of a language  there are
32 keywords in c

main()=> it is a function and need of each program of c because execution
of program always be start from main and end to main. it is backbone of
c program

{
  .... block of code
}
The statements which you want to execute must be enclosed inside this block
function 	header file 	work
clrscr()        conio.h         clear the output screen
printf()	stdio.h		print output on the screen
getch()		conio.h		take a character input and hold the screen untill press of any key

escape sequence characters
\n new line
\t tab
\b move cursor one step back
\r move cursor at begning of line
\" print double quotes on screen

				************
				*SIRCL TECH*
				************
*/
