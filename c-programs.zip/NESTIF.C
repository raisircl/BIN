/*
Nested if-else: when we use an if else statement into another if-else
syntax:
if(condition)
{
  if(condition)
  {

    ....

  }
  else
  {
     ...
  }
}
  else
  {
    .....

    if(condition)
    {
      ...
    }
    else
    {
      ...
    }

}
*/

#include<stdio.h>
#include<conio.h>
void main()
{
   int age;
   clrscr();
   printf("\nenter an age of a person");
   scanf("%d",&age); //10 ,25, 80
   // lic eligibility criteria age must be between 18-45
   if(age>=18)
   {
      if(age<=45)
      {
	 printf("\nEligibile for LIC");
      }
      else
      {
	 printf("\nNot Eligible for LIC");
      }
   }
   else
   {
     printf("\n Not Eligible for LIC");
   }
   getch();
}

/*
Biggest between 3 Nos
*/