#include<stdio.h>
#include<conio.h>
/*
  Function Return and Accept

  RT funName(DT,DT,...);

*/
int fact(int); // fact is a function it accept an int value and return int val

int ss(int); // write a fun that accept int value and return sum of all natural nos up to it.

//10 1+2+3+4+5+6+7+8+9+10=55

void main()
{
  int x;

  clrscr();

  x=fact(4); //4x3x2x1=24

  printf("\nFactorial is %d",x);

  getch();
}
int fact(int num)
{
  int i, f=1;
  for(i=1;i<=num;i++)
  {
    f=f*i;
  }
  return f;
}