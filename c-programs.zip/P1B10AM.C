/*
Aim - First Program of C
Authors - Sourav, Anmol, Vishal, Pawan
Date - 19 Sep 2023
Place - SIRCL TECH
*/
#include<stdio.h>
#include<conio.h>
void main()
{
  clrscr();
  printf("\nHello User");
  printf("\nWelcome in C");
  getch();
}//end of program