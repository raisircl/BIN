/*
Aim - First Program of C
Date - 18 Oct 2023
Place - SIRCL TECH
Author - Garv, Vishal and Pankaj
*/
#include<stdio.h>
#include<conio.h>
void main()
{
  clrscr();
  printf("\nHello User");
  printf("\nWelcome in C");
  getch();
}// end of program
/*
Symbols -
/ Forward Slash
- Dash
* Asterisk or Star
# hash
<> angular bracket
. dot
() parenthesis
; semicolon
"" double quotes
\ backward slash

{} braces
*/
