/*
Aim - Escape Sequence Characters Introduction
Date - 20 Sep 2023
Place - SIRCL TECH
*/

#include<stdio.h>
#include<conio.h>

int main()
{
  clrscr();
  printf("\nSIRCL\t\t\t\t\t\t\t\t\t   SIRCL");
  printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
  printf("\nSIRCL\t\t\t\t\t\t\t\t\t   SIRCL");
  getch();
  return 0;
}

