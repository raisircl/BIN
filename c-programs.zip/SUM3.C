#include<stdio.h>
#include<conio.h>
void main()
{
  int n1,n2,r;

  clrscr();

  n1=100;
  n2=200;

  r=n1+n2;

  printf("\nThe sum is %d",r);

  getch();
}
/*
-   5-2=3
*   5*2=10
/   5/2=>2
%   5%2=>1
*/