#include<stdio.h>
#include<conio.h>
void main()
{
  clrscr();
  printf("\nVishal\t\t\t\t\t\t\t\t\t  Vishal");
  printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
  printf("\nGarv\t\t\t\t\t\t\t\t\t    Garv");
  getch();
}

/*

				******
				*GARV*
				******

*****************************************************************************
*							                    *
*							                    *
*							                    *
*							                    *
*				  GARV			                    *
*							                    *
*							                    *
*							                    *
*							                    *
*****************************************************************************							                    *

*******
*     *
* * * *
*  *
*   *

*/