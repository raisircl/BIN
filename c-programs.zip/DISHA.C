#include<stdio.h>
#include<CONIO.H>
#include "DISHA.H"
void main()
{
  int r;
  clrscr();
  r=sum(100,2000);
  printf("\nThe sum is %d",r);
  getch();
}