/*
Aim - Sum of 2 Nos
*/
#include<stdio.h>
#include<conio.h>
void main()
{
  int n1,n2,r;   // declaration
  clrscr();

  n1=100;   // assignment
  n2=200;

  r=n1+n2;  // logic and using

  printf("\nThe sum is %d",r);  // using

  getch();
}
/*
 -   subtraction
 *   multiply
 /   div       5/2=>2
 %   modulas   5%2=>1

*/