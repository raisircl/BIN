#include<stdio.h>
#include<conio.h>
/*
Call By Reference
if any change in formal parameter it affects actual  paramater
*/
void fun(int*);
void main()
{
  int a=10;
  clrscr();
  printf("\nBefore call of fun A=%d",a);
  fun(&a); // a is actual parameter
  printf("\nAfter Call of Fun A=%d",a);
  getch();
}
void fun(int *x)  // x is formal parameter
{
  *x=100;
}
/*
Swaping of 2 nos using call by reference
*/