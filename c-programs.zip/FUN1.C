/*
 Function -
 It is set of instructions under a name.
 It is part of program.
 It is known as sub program
*/
#include<stdio.h>
#include<conio.h>

int msg()   // definition
{
   printf("\nHello User");
   printf("\nWelcome in C");
   //printf("\nI am doing C");
}

int main()
{
   clrscr();

   msg(); // calling

   printf("\nC Develop by Dennis Retchie");

   msg();

   printf("\nC Develop in 1972");

   msg();

   sum();

   getch();
}
sum()
{
  int n1,n2,r;
  printf("\nenter 2 nos");
  scanf("%d%d",&n1,&n2);
  r=n1+n2;
  printf("\nSum=%d",r);
  getch();
}
/*
output:

Hello User
Welcome in C

C Develop by Dennis Retchie

Hello User
Welcome in C

C Developed in 1972

Hello User
Welcome in C

I am learning C at SIRCL TECH

Hello User
Welcome in C

*/