/*
Aim - First Program of C
Date 5 Oct 2023
Author - Rai
*/

#include<stdio.h>
#include<conio.h>

void main()
{
   clrscr();
   printf("\nHello\t\t\t\t\t\t\t\t\t    User");
   printf("\n\n\n\n\n\n\n\nWelcome in C");
   getch();
}//end of program