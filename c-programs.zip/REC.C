/*
Recursion - When a function call itself then that function is known as
	    recursive function and process is known as recursion

*/
#include<stdio.h>
#include<conio.h>
int x=1;
void main()
{
   if(x<=10)
   {
   printf("\nHello");
   x++;
   main(); //recursion
   }
}
