/*
Function - Implementation Rule
1.  Declaration or Prototype of function (Always above the main() )
    Syntax -
       ReturnType FunctionName(DT, DT,...);

       example:

       void 	  msg();    // does not return and does not accept
       void	  sum(int,int); //
       void       table(int);

       int        fact(int);

       float       getpi();

       float      result(int,int,int,int,int);

       void mean - function does not return
       empty parenthesis - function does not accept

       Return	Accept
       No	No
       No	Yes
       Yes	Yes
       Yes	No

2.  Definition (Below the main() )
      Syntax -
      ReturnType FunctionName(DT var, DT var,...)
      {
	......
	......
	return value;  //optional
      }
3.  Calling    (Inside the main() )
    Sytax -

    funname(val,val,...);

*/
#include<stdio.h>
#include<conio.h>
void msg(); // does not accept and does not return
void sum();
void main() // a name which is given to set of instructions
{
   clrscr();

   msg(); // calling

   sum(); // calling

   msg();


   getch();

}
void msg() // definition
{
  printf("\nHello User");
  printf("\nWelcome to function");
}
void sum()
{
   int n1,n2,t;
   printf("\nenter 2 nos");
   scanf("%d%d",&n1,&n2);
   t=n1+n2;
   printf("\nSum=%d",t);
}