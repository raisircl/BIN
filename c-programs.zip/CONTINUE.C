/*
continue -
syntax -   <--------
for(  ;  ;  )      -
  {                -   transfer the control to next interation of loop
     .....         -   when it work its below statements skip for that time
     ....          -
     continue;------
     ..........
     ......
  }
*/
#include<stdio.h>
#include<conio.h>

void main()
{
   int i;
   clrscr();
   for(i=1;i<=10;i++)
   {
       if(i==5 || i==7)
       {
	 continue;
       }
       printf("\n%d",i);
   }
   getch();
}