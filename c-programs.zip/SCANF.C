/*
Aim - Input 2 Nos and print sum
To take input we need to learn scanf.
syntax:
	       1                 2
scanf("format-specifiers",&var1,&var2,...);

Note -
1.format specifiers(%d or %c or %f") must be adjacent
2.perfix & with each variable

%d  - deal with integers
%c  - deal with chars
%f  - deal with float

*/
#include<stdio.h>
#include<conio.h>
void main()
{
  int n1,n2,r;   // declaration
  clrscr();

  printf("\nenter 2 nos:");
  scanf("%d%d",&n1,&n2);

  r=n1+n2;  // logic and using

  printf("\nThe sum is %d",r);  // using
  //printf("\nThe sum of %d and %d is %d",n1,n2,r);
  //printf("\n %d\n+%d\n______\n %d",n1,n2,r);

  getch();
}
/*
 -   subtraction
 *   multiply
 /   div       5/2=>2
 %   modulas   5%2=>1

 1 .enter principle , rate and time print simple interest
 2. enter marks of 5 subjects and print sum and percentage
 3. enter mrp of book give 10% dis and print net price
 4. enter 2 nos and print their value after interchange
 5. enter 2 nos and print their value after swap(interchange)
    a=5 =>7
    b=7 =>5
 6. enter mrp of book give 10% dis then print net price
    mrp=100
    dis=mrp*10/100=>10
    net=mrp-dis=>90
 7. enter principle, rate and time and print simple interest
    si=p*r*t/100

*/