/*
Matrix - 2d array. It is used to store data in form of rows and columns.

syntax:

datatype matrix_name[rows][cols];
eg.

 int a[3][3]

   0    1   2
0 0,0  0,1 0,2
1 1,0  1,1 1,2
2 2,0  2,1 2,2

*/

#include<stdio.h>
#include<conio.h>

void main()
{
  int a[3][3],i,j;
  clrscr();
  for(i=0;i<3;i++)
  {
    for(j=0;j<3;j++)
    {
      printf("\nenter an element:");
      scanf("%d",&a[i][j]);
    }
  }
  printf("\nyour matrix output is \n");
  for(i=0;i<3;i++)
  {
    for(j=0;j<3;j++)
    {
      printf("%d\t",a[i][j]);
    }
    printf("\n");
  }
  getch();
}