/*
 Function -
*/
#include<stdio.h>
#include<conio.h>
void main()
{
   clrscr();

   printf("\nHello User");
   printf("\nWelcome in C");

   printf("\nC Develop by Dennis Retchie");

   printf("\nHello User");
   printf("\nWelcome in C");

   printf("\nC Develop in 1972");

   printf("\nHello User");
   printf("\nWelcome in C");
   getch();
}
/*
output:

Hello User
Welcome in C

C Develop by Dennis Retchie

Hello User
Welcome in C

C Developed in 1972

Hello User
Welcome in C

I am learning C at SIRCL TECH

Hello User
Welcome in C

*/