/*
if- else if - else
if(condition)
{
  ....
}
else if(condition)
{
 .....
}
else if(condition)
{
 ....
}
.
.
.
else
{
  .....
}
enter a day of the week and print name of the day
*/
#include<stdio.h>
#include<conio.h>
void main()
{
  int day;
  clrscr();
  printf("\nenter day of the week");
  scanf("%d",&day);
  if(day==1)
  {
    printf("\nToday is Monday");
  }
  else if(day==2)
  {
    printf("\nToday is Tuesday");
  }
  else if(day==3)
  {
    printf("\nToday is Wednesday");
  }
  else if(day==4)
  {
    printf("\nToday is Thursday");
  }
  else if(day==5)
  {
    printf("\nToday is Friday");
  }
  else if(day==6)
  {
    printf("\nToday is Saturday");
  }
  else if(day==7)
  {
    printf("\nToday is Sunday");
  }
  else
  {
    printf("\nenter a valid day of week between 1 - 7");
  }
  getch();
}
/*
enter a digit and print it in word
0 Zero
1 One
2 Two
3 Three
....
enter a month of a year print name of the month
1 Jan
2 Feb
...
*/

